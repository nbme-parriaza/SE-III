package org.nbme.seiiibackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeiiiBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
