package org.nbme.seiiibackend.repository;

import org.nbme.seiiibackend.model.County;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

public interface CountyRepository extends CrudRepository<County, Integer> {
}
