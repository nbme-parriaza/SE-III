package org.nbme.seiiibackend.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
@Data
public class County {

    @Id
    @Column
    private int id;

    @Column
    private String name;

    @Column
    private String rep_winner;

    @Column
    private String dem_winner;
}
