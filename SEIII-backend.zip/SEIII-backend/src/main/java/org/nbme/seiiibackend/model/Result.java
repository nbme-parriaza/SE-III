package org.nbme.seiiibackend.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table
@Data
@IdClass(ResultId.class)
public class Result implements Serializable {

    public Result() {}

    public Result(String county, String candidate) {
        this.county = county;
        this.candidate = candidate;
    }

    @Id
    @Column
    private String county;

    @Id
    @Column
    private String candidate;

    @Column
    private String party;

    @Column
    private int votes;

}
