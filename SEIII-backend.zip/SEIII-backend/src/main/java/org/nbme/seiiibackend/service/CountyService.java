package org.nbme.seiiibackend.service;

import org.nbme.seiiibackend.model.County;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.nbme.seiiibackend.repository.CountyRepository;
import java.util.ArrayList;
import java.util.List;

@Service
public class CountyService {

    @Autowired
    CountyRepository countyRepository;

    public List<County> getAllCounties() {
        List<County> counties = new ArrayList<County>();
        countyRepository.findAll().forEach(county -> counties.add(county));
        return counties;
    }


}
