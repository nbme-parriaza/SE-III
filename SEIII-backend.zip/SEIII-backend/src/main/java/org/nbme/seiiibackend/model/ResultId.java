package org.nbme.seiiibackend.model;

import java.io.Serializable;
import java.util.Objects;

public class ResultId implements Serializable {

    private String county;

    private String candidate;

    public ResultId() {};

    public ResultId(String county, String candidate) {
        this.county = county;
        this.candidate = candidate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ResultId resultId = (ResultId) o;
        return  county.equals(resultId.county) &&
                candidate.equals(resultId.candidate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(county, candidate);
    }
}
