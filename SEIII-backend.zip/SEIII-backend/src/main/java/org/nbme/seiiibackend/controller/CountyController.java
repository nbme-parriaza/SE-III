package org.nbme.seiiibackend.controller;

import org.nbme.seiiibackend.model.County;
import org.nbme.seiiibackend.service.CountyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CountyController {

    CountyService countyService;

    @GetMapping("/county")
    private List<County> getAllCounties() {
        return countyService.getAllCounties();
    }
}
