# Objectives
- Fix errors
- Read .json file and add data to "Result" table
- create an endpoint to return the winning primary candidates in each county (republican and democratic winner)
- create an endpoint to return the winning primary candidates overall
