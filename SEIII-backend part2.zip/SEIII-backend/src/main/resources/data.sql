DROP TABLE IF EXISTS county;
CREATE TABLE county (countyId INT, name VARCHAR(64) primary key );
insert into county (countyId, name) values (1, 'Adams');
insert into county (countyId, name) values (2, 'Allegheny');
insert into county (countyId, name) values (3, 'Armstrong');
insert into county (countyId, name) values (4, 'Beaver');
insert into county (countyId, name) values (5, 'Bedford');
insert into county (countyId, name) values (6, 'Berks');
-- insert into county (countyId, name) values (7, 'Blair');
-- insert into county (countyId, name) values (8, 'Bradford');
-- insert into county (countyId, name) values (9, 'Bucks');
-- insert into county (countyId, name) values (10, 'Butler');
-- insert into county (countyId, name) values (11, 'Cambria');
-- insert into county (countyId, name) values (12, 'Cameron');
-- insert into county (countyId, name) values (13, 'Carbon');
-- insert into county (countyId, name) values (14, 'Centre');
-- insert into county (countyId, name) values (15, 'Chester');
-- insert into county (countyId, name) values (16, 'Clarion');
-- insert into county (countyId, name) values (17, 'Clearfield');
-- insert into county (countyId, name) values (18, 'Clinton');
-- insert into county (countyId, name) values (19, 'Columbia');
-- insert into county (countyId, name) values (20, 'Crawford');
-- insert into county (countyId, name) values (21, 'Cumberland');
-- insert into county (countyId, name) values (22, 'Dauphin');
-- insert into county (countyId, name) values (23, 'Delaware');
-- insert into county (countyId, name) values (24, 'Elk');

DROP TABLE IF EXISTS result;
CREATE TABLE result (resultId int, countyId int, candidate VARCHAR(64), party VARCHAR(64), votes INT, PRIMARY KEY (resultId));

DROP TABLE IF EXISTS winners;
CREATE TABLE winners (countyId VARCHAR(64), party VARCHAR(64), candidate VARCHAR(64), primary key (countyId, party))
