package org.nbme.seiiibackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeiiiBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(SeiiiBackendApplication.class, args);
    }

}
