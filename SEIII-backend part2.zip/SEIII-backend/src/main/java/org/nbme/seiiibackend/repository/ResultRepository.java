package org.nbme.seiiibackend.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ResultRepository extends CrudRepository<Result, ResultId> {
    Result findByCountyAndCandidate(String county, String candidate);
}
