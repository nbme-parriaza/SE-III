package org.nbme.seiiibackend.model;

import lombok.Data;

import javax.persistence.Entity;

@Entity
@Data
public class Result {
}
