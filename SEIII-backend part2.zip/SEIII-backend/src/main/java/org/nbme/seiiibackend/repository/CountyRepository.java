package org.nbme.seiiibackend.repository;

import org.nbme.seiiibackend.model.County;
import org.springframework.data.repository.CrudRepository;

public interface CountyRepository extends CrudRepository<County, Integer> {
}
